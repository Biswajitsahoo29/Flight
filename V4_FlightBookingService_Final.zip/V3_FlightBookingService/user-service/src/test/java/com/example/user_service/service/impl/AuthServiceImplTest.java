package com.example.user_service.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.user_service.dto.AuthResponseDto;
import com.example.user_service.dto.LoginRequestDto;
import com.example.user_service.entity.User;
import com.example.user_service.repository.UserRepository;
import com.example.user_service.security.JwtService;
import com.example.user_service.service.UserService;

class AuthServiceImplTest {

    @Test
    void loginShouldExposeUserNameInAuthResponse() {
        UserService userService = mock(UserService.class);
        UserRepository userRepository = mock(UserRepository.class);
        PasswordEncoder passwordEncoder = mock(PasswordEncoder.class);
        JwtService jwtService = mock(JwtService.class);

        User user = new User();
        user.setId(7L);
        user.setEmail("sam@example.com");
        user.setPassword("secret");
        user.setFirstName("Sam");
        user.setLastName("Patel");
        user.setRole("ROLE_USER");

        when(userRepository.findByEmail("sam@example.com")).thenReturn(java.util.Optional.of(user));
        when(passwordEncoder.matches("secret", "secret")).thenReturn(true);
        when(jwtService.generateToken("sam@example.com", "ROLE_USER")).thenReturn("token-123");

        AuthServiceImpl authService = new AuthServiceImpl(userService, userRepository, passwordEncoder, jwtService);
        AuthResponseDto response = authService.login(new LoginRequestDto("sam@example.com", "secret"));

        assertNotNull(response);
        assertEquals("Sam", response.getFirstName());
        assertEquals("Patel", response.getLastName());
    }
}
