import { Link } from '../routes/Link'

export function Layout({ children, loading, notice, stats, onRefresh, user, onLogout }) {
  const isAdmin = user?.role === 'ROLE_ADMIN' || user?.role === 'ADMIN'
  const hasSession = Boolean(user)

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <h1 className="eyebrow">AeroSwift</h1>
          <p>Search, reserve, book, and issue tickets in one flow.</p>
        </div>
        <div className="header-actions">
          {hasSession ? (
            <>
              <span className="user-chip">{user.email}</span>
              <button className="ghost-btn" type="button" onClick={onLogout}>Sign out</button>
              <button className="ghost-btn" type="button" onClick={onRefresh} disabled={loading}>Refresh</button>
            </>
          ) : (
            <>
              <Link href="/login" label="Sign in" />
              <Link href="/register" label="Register" />
            </>
          )}
        </div>
      </header>

      <section className="hero-band">
        <div className="search-panel">
          {hasSession && (
            <nav className="tabs" aria-label="Primary views">
              {!isAdmin && <Link href="/booking" label="Book flights" />}
              {!isAdmin && <Link href="/bookings" label="My bookings" />}
              <Link href="/profile" label="Profile" />
              {isAdmin && <Link href="/manage" label="Manage services" />}
            </nav>
          )}
          {children}
        </div>
      </section>

      <StatusStrip loading={loading} notice={notice} stats={stats} />
    </main>
  )
}

function StatusStrip({ loading, notice, stats }) {
  return (
    <section className="status-strip">
      {stats.map(([label, value]) => (
        <div key={label}>
          <span>{label}</span>
          <strong>{value}</strong>
        </div>
      ))}
      <p className={notice.toLowerCase().includes('failed') ? 'notice error' : 'notice'}>
        {loading ? 'Working with services...' : notice || 'Ready.'}
      </p>
    </section>
  )
}
