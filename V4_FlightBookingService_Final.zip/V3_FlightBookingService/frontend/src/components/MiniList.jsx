export function MiniList({ items, title, detail, onEdit, onDelete, onToggle, toggleLabel, maxItems }) {
  const renderItems = maxItems ? items.slice(0, maxItems) : items

  return (
    <div className="mini-list">
      {renderItems.map((item) => (
        <article key={item.id}>
          <div>
            <strong>{title(item)}</strong>
            <span>{detail(item)}</span>
          </div>
          <div className="row-actions">
            <button type="button" onClick={() => onEdit(item)}>
              Edit
            </button>
            {onToggle && (
              <button type="button" onClick={() => onToggle(item)}>
                {toggleLabel(item)}
              </button>
            )}
            <button type="button" onClick={() => onDelete(item)}>
              Delete
            </button>
          </div>
        </article>
      ))}
      {!items.length && <p className="compact">No records yet.</p>}
    </div>
  )
}
