export function normalizeFlight(form) {
  return {
    ...form,
    price: Number(form.price),
    availableSeats: Number(form.availableSeats),
    totalSeats: Number(form.totalSeats),
  }
}

export function normalizeSeat(form) {
  const { flightNumber, ...rest } = form
  return {
    ...rest,
    flightId: Number(rest.flightId),
    price: Number(rest.price),
  }
}

export function normalizeBooking(form) {
  return {
    userId: Number(form.userId),
    flightId: Number(form.flightId),
    seatId: Number(form.seatId),
    bookingStatus: form.bookingStatus,
    paymentStatus: form.paymentStatus,
    totalFare: Number(form.totalFare),
  }
}
