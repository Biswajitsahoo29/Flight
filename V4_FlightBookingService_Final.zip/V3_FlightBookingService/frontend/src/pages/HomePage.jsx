import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { Select } from '../components/FormControls'
import { FlightCard } from '../components/FlightCard'
import { searchApi, flightApi } from '../api'
import { today } from '../utils/date'

const departureDateOptions = Array.from({ length: 14 }, (_, index) => {
  const date = new Date()
  date.setDate(date.getDate() + index)
  const value = date.toISOString().slice(0, 10)
  return {
    label: `${value}`,
    value,
  }
})

export function HomePage() {
  const navigate = useNavigate()
  const user = useSelector((state) => state.auth.user)
  const [airportOptions, setAirportOptions] = useState([])
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [notice, setNotice] = useState('')

  useEffect(() => {
    const loadAirportOptions = async () => {
      try {
        const flights = await flightApi.list()
        setAirportOptions(
          Array.from(
            new Set(
              flights
                .flatMap((flight) => [flight.source, flight.destination])
                .filter(Boolean),
            ),
          ).sort((a, b) => a.localeCompare(b)),
        )
      } catch (error) {
        console.warn('Unable to load airport options', error)
      }
    }

    loadAirportOptions()
  }, [])

  const handleSearch = async (event) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const source = form.get('source')
    const destination = form.get('destination')
    const departureDate = form.get('departureDate')
    const numberOfPassengers = form.get('numberOfPassengers')
    const travelClass = form.get('travelClass')

    setLoading(true)
    setNotice('')
    try {
      const matches = await searchApi.searchFlights({ source, destination, departureDate, numberOfPassengers, travelClass })
      setResults(matches)
      setNotice(matches.length ? `${matches.length} flights found.` : 'No flights found for that route.')
    } catch (error) {
      setNotice(error.message || 'Search failed.')
      setResults([])
    } finally {
      setLoading(false)
    }
  }

  const goToBooking = (flight) => {
    navigate('/booking', {
      state: {
        source: flight.source,
        destination: flight.destination,
        departureDate: flight.departureDate,
      },
    })
  }

  return (
    <section className="home-page">
      <div className="home-card">
        <h2>Search flights</h2>
        <p>{user ? 'Start by choosing origin, destination, and travel date.' : 'Please sign in or register to search and book flights.'}</p>
        <form className="home-search" onSubmit={handleSearch}>
          <Select label="From" name="source" options={airportOptions} required />
          <Select label="To" name="destination" options={airportOptions} required />
          <Select label="Depart" name="departureDate" options={departureDateOptions} defaultValue={today} required />
          <label>
            <span>Passengers</span>
            <input name="numberOfPassengers" type="number" min="1" defaultValue="1" required />
          </label>
          <Select label="Class" name="travelClass" options={['Economy', 'Business', 'First']} required />
          <button className="primary-btn" type="submit" disabled={loading}>
            {loading ? 'Searching…' : 'Search flights'}
          </button>
        </form>
        {!user && (
          <div className="home-actions">
            <Link className="primary-btn text-center" to="/login">Sign in</Link>
            <Link className="ghost-btn" to="/register">Register</Link>
          </div>
        )}
        {notice && <p className="notice">{notice}</p>}
      </div>
      {results.length > 0 && (
        <section className="results-list">
          {results.map((flight) => (
            <FlightCard
              key={flight.id}
              flight={flight}
              onSelect={goToBooking}
              selected={false}
            />
          ))}
        </section>
      )}
    </section>
  )
}
