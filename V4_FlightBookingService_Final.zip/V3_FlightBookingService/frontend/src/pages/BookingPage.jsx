import { useState, useEffect, Fragment } from 'react'
import { useSelector } from 'react-redux'
import { useLocation, useNavigate } from 'react-router-dom'
import { bookingApi, flightApi, searchApi, seatApi, ticketApi } from '../api'
import { Field, Select } from '../components/FormControls'
import { FlightCard } from '../components/FlightCard'
import { today } from '../utils/date'
import { formatMoney } from '../utils/format'

const seatColumns = ['A', 'B', 'C', 'D']

const normalizeSeatNumber = (raw = '') => {
  const s = String(raw || '').trim().toUpperCase()
  const m1 = /^([A-Z])(\d+)$/i.exec(s)
  if (m1) return `${m1[1]}${Number(m1[2])}`
  const m2 = /^(\d+)([A-Z])$/i.exec(s)
  if (m2) return `${m2[2].toUpperCase()}${Number(m2[1])}`
  return s
}

export function BookingPage({ users, refreshData, setLoading, setNotice, showToast }) {
  const currentUser = useSelector((state) => state.auth.user)
  const location = useLocation()
  const [searchForm, setSearchForm] = useState({
    source: '',
    destination: '',
    departureDate: '',
    returnDate: '',
    numberOfPassengers: 1,
    travelClass: 'Economy',
  })
  const [airportOptions, setAirportOptions] = useState([])
  const [results, setResults] = useState([])
  const [selectedFlight, setSelectedFlight] = useState(null)
  const [flightSeats, setFlightSeats] = useState([])
  const [selectedSeat, setSelectedSeat] = useState(null)
  const [departureDateOptions, setDepartureDateOptions] = useState([])
  const [bookingForm, setBookingForm] = useState({ userId: '', paymentStatus: 'PAID' })
  const [latestBooking, setLatestBooking] = useState(null)
  const [latestTicket, setLatestTicket] = useState(null)

  const setField = (setter) => (event) => {
    const { name, value } = event.target
    setter((current) => ({ ...current, [name]: value }))
  }

  useEffect(() => {
    if (location.state) {
      setSearchForm((current) => ({
        ...current,
        source: location.state.source || current.source,
        destination: location.state.destination || current.destination,
        departureDate: location.state.departureDate || current.departureDate,
      }))
    }
  }, [location.state])

  useEffect(() => {
    const loadAirportOptions = async () => {
      try {
        const flights = await flightApi.list()
        const uniqueOptions = Array.from(
          new Set(
            flights
              .flatMap((flight) => [flight.source, flight.destination])
              .filter(Boolean),
          ),
        )
          .sort((a, b) => a.localeCompare(b))

        const extras = [searchForm.source, searchForm.destination].filter(Boolean)
        setAirportOptions(Array.from(new Set([...uniqueOptions, ...extras])))
      } catch (error) {
        console.warn('Unable to load airport options', error)
      }
    }
    loadAirportOptions()
  }, [searchForm.source, searchForm.destination])

  useEffect(() => {
    const loadAvailableDates = async () => {
      const { source, destination } = searchForm
      if (!source || !destination || source === destination) {
        setDepartureDateOptions([])
        setSearchForm((current) => ({ ...current, departureDate: '' }))
        return
      }

      try {
        const flights = await flightApi.list()
        const dateOptions = [...new Set(
          flights
            .filter((flight) =>
              flight.source?.toLowerCase() === source.toLowerCase() &&
              flight.destination?.toLowerCase() === destination.toLowerCase() &&
              Number(flight.availableSeats) > 0,
            )
            .map((flight) => flight.departureDate)
            .filter(Boolean),
        )]
          .sort()
          .map((value) => ({ label: value, value }))

        setDepartureDateOptions(dateOptions)
        setSearchForm((current) => {
          if (dateOptions.some((option) => option.value === current.departureDate)) {
            return current
          }
          return { ...current, departureDate: dateOptions[0]?.value || '' }
        })
      } catch (error) {
        setDepartureDateOptions([])
        fail(error)
      }
    }

    loadAvailableDates()
  }, [searchForm.source, searchForm.destination])

  const buildSeatGrid = (seats) => {
    const rows = {}

    seats.forEach((seat) => {
      const sn = normalizeSeatNumber(seat.seatNumber)
      const match = /^([A-D])(\d+)$/i.exec(sn)
      const column = match ? match[1].toUpperCase() : null
      const rowNumber = match ? Number(match[2]) : null
      const rowKey = rowNumber ?? 0

      if (!rows[rowKey]) rows[rowKey] = {}

      if (column && seatColumns.includes(column)) {
        rows[rowKey][column] = seat
      } else {
        const fallbackColumn = seatColumns.find((col) => !rows[rowKey][col])
        if (fallbackColumn) rows[rowKey][fallbackColumn] = seat
      }
    })

    return Object.entries(rows)
      .map(([row, seats]) => ({ row: Number(row), seats }))
      .sort((a, b) => a.row - b.row)
  }

    const ensureFullSeatList = (flight, seatsFromApi = []) => {
    const columns = seatColumns
    const seatMap = new Map()
    seatsFromApi.forEach((s) => seatMap.set(normalizeSeatNumber(s.seatNumber), s))

      const totalSeats = Number(flight?.totalSeats) || 0
      const maxRowFromApi = seatsFromApi.reduce((max, s) => {
      const sn = normalizeSeatNumber(s.seatNumber)
      const m = /^([A-D])(\d+)$/i.exec(sn)
      const row = m ? Number(m[2]) : 0
      return Math.max(max, row || 0)
    }, 0)

    const estimatedRows = totalSeats ? Math.ceil(totalSeats / columns.length) : 0
    const rows = Math.max(1, maxRowFromApi || estimatedRows || 30)

    const full = []
    for (let c = 0; c < columns.length; c += 1) {
      for (let r = 1; r <= rows; r += 1) {
        const seatNumber = `${columns[c]}${r}`
        const existing = seatMap.get(seatNumber)
        if (existing) {
          full.push(existing)
        } else {
          full.push({
            id: null,
            flightId: flight.id,
            seatNumber,
            status: 'AVAILABLE',
            price: flight.price,
            seatClass: undefined,
          })
        }
      }
    }

   
    const classByRow = {}
    seatsFromApi.forEach((s) => {
      const sn = normalizeSeatNumber(s.seatNumber)
      const m = /^([A-D])(\d+)$/i.exec(sn)
      const row = m ? Number(m[2]) : null
      if (row) {
        classByRow[row] = classByRow[row] || {}
        if (s.seatClass) classByRow[row][s.seatClass] = (classByRow[row][s.seatClass] || 0) + 1
      }
    })

    const determineClassForRow = (rowIndex) => {
      const counts = classByRow[rowIndex]
      if (counts) {
       
        return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0]
      }
      if (rows <= 6) return 'Economy'
      if (rowIndex <= Math.max(1, Math.floor(rows * 0.05))) return 'First'
      if (rowIndex <= Math.max(3, Math.floor(rows * 0.2))) return 'Business'
      return 'Economy'
    }

    full.forEach((s) => {
      const sn = normalizeSeatNumber(s.seatNumber)
      const m = /^([A-D])(\d+)$/i.exec(sn)
      const row = m ? Number(m[2]) : 0
      if (!s.seatClass) s.seatClass = determineClassForRow(row)
    })

    return full
  }

  const success = (message) => {
    setNotice(message)
    showToast(message, 'success')
  }

  const fail = (error) => {
    setNotice(error.message)
    showToast(error.message, 'error')
  }

  const handleSearch = async (event) => {
    event.preventDefault()
    setLoading(true)
    setSelectedFlight(null)
    setSelectedSeat(null)
    setLatestBooking(null)
    setLatestTicket(null)
    try {
      const matches = await searchApi.searchFlights({
        ...searchForm,
        returnDate: searchForm.returnDate || '',
      })
      setResults(matches)
      success(matches.length ? 'Flights matched your route.' : 'No flights found.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const navigate = useNavigate()

  const chooseFlight = async (flight) => {
    setSelectedFlight(flight)
    setSelectedSeat(null)
    setLatestBooking(null)
    setLatestTicket(null)
    setLoading(true)
    try {
      const seats = await seatApi.byFlight(flight.id)
      const full = ensureFullSeatList(flight, seats || [])
      setFlightSeats(full)
      success(`Choose a seat for ${flight.flightNumber}.`)
    } catch (error) {
      setFlightSeats([])
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const confirmBooking = async (event) => {
    event.preventDefault()
    if (!selectedFlight || !selectedSeat) {
      success('Select a flight and an available seat first.')
      return
    }
    setLoading(true)
    try {
      // If the selected seat is client-synthesized (no id), create/reserve it first
      let seatToUse = selectedSeat
      if (!seatToUse.id) {
        const created = await seatApi.create({
          flightId: selectedFlight.id,
          seatNumber: seatToUse.seatNumber,
          price: seatToUse.price,
          seatClass: seatToUse.seatClass,
          status: 'RESERVED',
        })
        seatToUse = created
        setSelectedSeat(created)
      }
      const booking = await bookingApi.create({
        userId: Number(bookingForm.userId),
        flightId: selectedFlight.id,
        seatId: seatToUse.id,
        bookingStatus: 'PENDING',
        paymentStatus: 'PENDING',
        totalFare: Number(selectedSeat.price || selectedFlight.price),
      })
      setLatestBooking(booking)
      success(`Booking created: ${booking.bookingReference}`)
      await refreshData()
      navigate('/payment', {
        state: {
          booking: {
            ...booking,
            flightNumber: selectedFlight.flightNumber,
            source: selectedFlight.source,
            destination: selectedFlight.destination,
            departureDate: selectedFlight.departureDate,
            seatNumber: selectedSeat.seatNumber,
          },
        },
      })
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const generateTicket = async () => {
    if (!latestBooking) return
    setLoading(true)
    try {
      const ticket = await ticketApi.generate({
        bookingId: latestBooking.id,
        ticketStatus: 'ISSUED',
      })
      setLatestTicket(ticket)
      success(`Ticket issued: ${ticket.ticketNumber}`)
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const cancelBooking = async () => {
    if (!latestBooking) return
    setLoading(true)
    try {
      await bookingApi.cancel(latestBooking.id)
      setLatestBooking((current) => ({ ...current, bookingStatus: 'CANCELLED' }))
      success('Booking cancelled and seat released.')
      await refreshData()
    } catch (error) { fail(error) } finally { setLoading(false) }
  }

  const downloadTicket = async () => {
    if (!latestTicket) return
    try {
      const blob = await ticketApi.download(latestTicket.id)
      const url = URL.createObjectURL(blob); const anchor = document.createElement('a')
      anchor.href = url; anchor.download = `${latestTicket.ticketNumber || `ticket-${latestTicket.id}`}.pdf`; anchor.click(); URL.revokeObjectURL(url)
    } catch (error) { fail(error) }
  }

  const availableSeats = flightSeats.filter((seat) => seat.status === 'AVAILABLE')
  const getPassengerLabel = (user) => {
    const name = [user?.firstName, user?.lastName].filter(Boolean).join(' ').trim()
    return name || user?.email || `Passenger ${user?.id || ''}`.trim()
  }

  return (
    <div className="traveler-grid">
      <form className="booking-search" onSubmit={handleSearch}>
        <Select label="From" name="source" value={searchForm.source} onChange={setField(setSearchForm)} options={airportOptions} />
        <Select label="To" name="destination" value={searchForm.destination} onChange={setField(setSearchForm)} options={airportOptions} />
        <Select label="Depart" name="departureDate" value={searchForm.departureDate} onChange={setField(setSearchForm)} options={departureDateOptions} />
        <Field label="Return" name="returnDate" type="date" value={searchForm.returnDate} onChange={setField(setSearchForm)} />
        <Field label="Passengers" name="numberOfPassengers" type="number" min="1" value={searchForm.numberOfPassengers} onChange={setField(setSearchForm)} />
        <Select label="Class" name="travelClass" value={searchForm.travelClass} onChange={setField(setSearchForm)} options={['Economy', 'Business', 'First']} />
        <button className="primary-btn" type="submit">Search flights</button>
      </form>

      <div className="results-list">
        {results.map((flight) => (
          <FlightCard
            flight={flight}
            key={flight.id}
            onSelect={chooseFlight}
            selected={selectedFlight?.id === flight.id}
          />
        ))}
      </div>

      <aside className="checkout-panel">
        <h2>Seat and checkout</h2>
        {selectedFlight ? (
          <>
            <p className="compact">
              {selectedFlight.flightNumber} from {selectedFlight.source} to {selectedFlight.destination}
            </p>
            <div className="seat-map">
              <div className="seat-header" />
              {seatColumns.map((column) => (
                <div key={column} className="seat-header">
                  {column}
                </div>
              ))}

              {(() => {
                // group by class first so classes render in blocks
                const byClass = {}
                buildSeatGrid(flightSeats).forEach((rowData) => {
                  const row = rowData.row
                  const rowSeats = rowData.seats
                  const anySeat = Object.values(rowSeats).find(Boolean)
                  const cls = (anySeat && anySeat.seatClass) || 'Economy'
                  byClass[cls] = byClass[cls] || []
                  byClass[cls].push({ row, seats: rowSeats })
                })

                return Object.keys(byClass).map((cls) => (
                  <Fragment key={cls}>
                    <div className={`seat-class-header seat-class-${cls.toLowerCase()}`}>{cls}</div>
                    {byClass[cls].map((rowData) => (
                      <Fragment key={`${cls}-${rowData.row}`}>
                        <div className="seat-row-label">{rowData.row}</div>
                        {seatColumns.map((column) => {
                          const seat = rowData.seats[column]
                          if (!seat) return <div key={`${rowData.row}-${column}`} className="seat-placeholder" />

                          const isAvailable = seat.status === 'AVAILABLE'
                          const isSelected = selectedSeat?.seatNumber === seat.seatNumber && selectedSeat?.flightId === seat.flightId

                          return (
                            <button
                              key={`${seat.seatNumber}-${seat.flightId}-${seat.id || 's'}`}
                              type="button"
                              className={`seat ${seat.status === 'RESERVED' ? 'reserved' : ''}${isSelected ? ' selected' : ''}`}
                              disabled={!isAvailable}
                              onClick={() => isAvailable && setSelectedSeat(seat)}
                            >
                              <span>{seat.seatNumber}</span>
                              <small>{formatMoney(seat.price)}</small>
                            </button>
                          )
                        })}
                      </Fragment>
                    ))}
                  </Fragment>
                ))
              })()}
            </div>
            <div className="seat-debug">
              <strong>Debug:</strong>
              <div>flightSeats count: {flightSeats.length}</div>
              <div>rows computed: {buildSeatGrid(flightSeats).length}</div>
              <div>sample seats: {flightSeats.slice(0, 60).map((s) => s.seatNumber).join(', ')}</div>
            </div>
            <form onSubmit={confirmBooking}>
              <Select
                label="Passenger"
                name="userId"
                value={bookingForm.userId}
                onChange={setField(setBookingForm)}
                options={(users.length ? users : currentUser ? [currentUser] : []).map((user) => ({
                  label: getPassengerLabel(user),
                  value: user.id,
                }))}
              />
              <button className="primary-btn" type="submit">Confirm booking</button>
            </form>
          </>
        ) : (
          <p className="compact">Select a flight to see available seats.</p>
        )}

        {latestBooking && (
          <div className="ticket-box">
            <strong>{latestBooking.bookingReference}</strong>
            <span>Seat {latestBooking.seatNumber}</span>
            {latestBooking.bookingStatus !== 'CANCELLED' && <button type="button" onClick={cancelBooking}>Cancel booking</button>}
            <button type="button" onClick={generateTicket}>Generate ticket</button>
          </div>
        )}
        {latestTicket && (
          <div className="ticket-box issued">
            <strong>{latestTicket.ticketNumber}</strong>
            <span>{latestTicket.ticketStatus}</span>
            <button type="button" onClick={downloadTicket}>Download PDF ticket</button>
          </div>
        )}
      </aside>
    </div>
  )
}
