import { useState } from 'react'
import { apiByResource, bookingApi, flightApi, seatApi, ticketApi, userApi } from '../api'
import { Field, Select } from '../components/FormControls'
import { MiniList } from '../components/MiniList'
import { Panel } from '../components/Panel'
import { today } from '../utils/date'
import { emptyBookingEdit, emptyFlight, emptySeat, emptyTicketEdit, emptyUser } from '../utils/forms'
import { formatMoney, labelize } from '../utils/format'
import { normalizeBooking, normalizeFlight, normalizeSeat } from '../utils/normalizers'

export function ManagementPage({ data, refreshData, setLoading, setNotice, showToast }) {
  const [flightForm, setFlightForm] = useState(emptyFlight)
  const [userForm, setUserForm] = useState(emptyUser)
  const [seatForm, setSeatForm] = useState(emptySeat)
  const [bookingEdit, setBookingEdit] = useState(emptyBookingEdit)
  const [ticketEdit, setTicketEdit] = useState(emptyTicketEdit)
  const [showFlightForm, setShowFlightForm] = useState(false)
  const [showUserForm, setShowUserForm] = useState(false)
  const [showSeatForm, setShowSeatForm] = useState(false)
  const [showBookingForm, setShowBookingForm] = useState(false)
  const [showTicketForm, setShowTicketForm] = useState(false)
  const [activeTab, setActiveTab] = useState('Users')
  const [apiTools, setApiTools] = useState({
    lookupService: 'flights',
    lookupId: '',
    lookupResult: null,
    flightSearchSource: 'Delhi',
    flightSearchDestination: 'Mumbai',
    flightSearchDate: today,
    flightSearchPassengers: 1,
    flightSearchResult: null,
    ticketBookingId: '',
    ticketLookupResult: null,
    directTicketBookingId: '',
    directTicketResult: null,
    bookingsUserId: '',
    bookingsByUserResult: null,
    syncFlightId: '',
  })

  const setField = (setter) => (event) => {
    const { name, value } = event.target
    setter((current) => ({ ...current, [name]: value }))
  }

  const getFlightNumberForId = (flightId) =>
    data.flights.find((flight) => flight.id === Number(flightId))?.flightNumber || ''

  const getFlightIdForNumber = (flightNumber) =>
    data.flights.find((flight) => flight.flightNumber === flightNumber)?.id

  const flightOptions = data.flights.map((flight) => ({
    label: `${flight.flightNumber} (${flight.source}-${flight.destination})`,
    value: flight.flightNumber,
  }))

  const success = (message) => {
    setNotice(message)
    showToast(message, 'success')
  }

  const fail = (error) => {
    setNotice(error.message)
    showToast(error.message, 'error')
  }

  const run = async (action, successMessage) => {
    setLoading(true)
    try {
      await action()
      success(successMessage)
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const saveFlight = (event) => {
    event.preventDefault()
    return run(async () => {
      if (flightForm.id) await flightApi.update(flightForm.id, normalizeFlight(flightForm))
      else await flightApi.create(normalizeFlight(flightForm))
      setFlightForm(emptyFlight)
      setShowFlightForm(false)
    }, 'Flight saved.')
  }

  const saveUser = (event) => {
    event.preventDefault()
    return run(async () => {
      if (userForm.id) await userApi.update(userForm.id, userForm)
      else await userApi.create(userForm)
      setUserForm(emptyUser)
      setShowUserForm(false)
    }, 'User saved.')
  }

  const saveSeat = (event) => {
    event.preventDefault()
    return run(async () => {
      const flightId = getFlightIdForNumber(seatForm.flightNumber) || seatForm.flightId
      const payload = normalizeSeat({ ...seatForm, flightId })
      if (seatForm.id) await seatApi.update(seatForm.id, payload)
      else await seatApi.create(payload)
      setSeatForm(emptySeat)
      setShowSeatForm(false)
    }, 'Seat saved.')
  }

  const updateBooking = (event) => {
    event.preventDefault()
    return run(
      () => bookingApi.update(bookingEdit.id, normalizeBooking(bookingEdit)),
      'Booking updated.',
    ).finally(() => setShowBookingForm(false))
  }

  const updateTicket = (event) => {
    event.preventDefault()
    return run(
      () => ticketApi.update(ticketEdit.id, {
        bookingId: Number(ticketEdit.bookingId),
        ticketStatus: ticketEdit.ticketStatus,
      }),
      'Ticket updated.',
    ).finally(() => setShowTicketForm(false))
  }

  const remove = (resource, id) =>
    run(() => apiByResource[resource].remove(id), `${resource.slice(0, -1)} deleted.`)

  const reserveOrRelease = (seat) =>
    run(
      () => (seat.status === 'AVAILABLE' ? seatApi.reserve(seat.id) : seatApi.release(seat.id)),
      'Seat status changed.',
    )

  const editFlight = (flight) => {
    setFlightForm(flight)
    setShowFlightForm(true)
  }

  const editUser = (user) => {
    setUserForm({ ...user, password: '' })
    setShowUserForm(true)
  }

  const editSeat = (seat) => {
    setSeatForm({ ...seat, flightNumber: getFlightNumberForId(seat.flightId) })
    setShowSeatForm(true)
  }

  const editBooking = (booking) => {
    setBookingEdit(booking)
    setShowBookingForm(true)
  }

  const editTicket = (ticket) => {
    setTicketEdit(ticket)
    setShowTicketForm(true)
  }

  const cancelTicket = (id) => run(() => ticketApi.cancel(id), 'Ticket cancelled.')

  const lookupRecord = async (event) => {
    event.preventDefault()
    setLoading(true)
    try {
      const result = await apiByResource[apiTools.lookupService].get(apiTools.lookupId)
      setApiTools((current) => ({ ...current, lookupResult: result }))
      success('Record loaded by ID.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const runFlightServiceSearch = async (event) => {
    event.preventDefault()
    setLoading(true)
    try {
      const result = await flightApi.search({
        source: apiTools.flightSearchSource,
        destination: apiTools.flightSearchDestination,
        departureDate: apiTools.flightSearchDate,
        numberOfPassengers: apiTools.flightSearchPassengers,
      })
      setApiTools((current) => ({ ...current, flightSearchResult: result }))
      success('Direct flight-service search complete.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const lookupTicketByBooking = async (event) => {
    event.preventDefault()
    setLoading(true)
    try {
      const result = await ticketApi.byBooking(apiTools.ticketBookingId)
      setApiTools((current) => ({ ...current, ticketLookupResult: result }))
      success('Ticket loaded by booking ID.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const createTicketDirect = (event) => {
    event.preventDefault()
    return run(async () => {
      const result = await ticketApi.create({
        bookingId: Number(apiTools.directTicketBookingId),
        ticketStatus: 'ISSUED',
      })
      setApiTools((current) => ({ ...current, directTicketResult: result }))
    }, 'Ticket generated through POST /tickets.')
  }

  const lookupBookingsByUser = async (event) => {
    event.preventDefault(); setLoading(true)
    try { 
      const result = await bookingApi.byUser(apiTools.bookingsUserId); 
      setApiTools((current) => ({ ...current, bookingsByUserResult: result })); 
      success('User bookings loaded.') 
    } catch (error) { 
      fail(error) 
    } finally {
       setLoading(false)
   }
  }

  const cancelTicketByBooking = (event) => {
    event.preventDefault(); 
    return run(() => 
      ticketApi.cancelByBooking(apiTools.ticketBookingId), 'Ticket cancelled by booking ID.')
  }

  const syncFlightSeats = (direction) => run(() => 
    direction === 'decrease' ? 
  flightApi.decreaseAvailableSeats(apiTools.syncFlightId) 
  : flightApi.increaseAvailableSeats(apiTools.syncFlightId), `Flight availability ${direction}d.`)

  const tabs = ['Users', 'Flights', 'Seats', 'Bookings', 'Tickets', 'API Tools']

  return (
    <div className="management-shell">
      <div className="management-tabs">
        {tabs.map((tab) => (
          <button
            key={tab}
            type="button"
            className={`management-tab${activeTab === tab ? ' active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="management-content">
        {activeTab === 'API Tools' && (
          <Panel title="API tools">
            <form onSubmit={lookupRecord}>
              <Select label="Service" name="lookupService" value={apiTools.lookupService} onChange={setField(setApiTools)} options={['flights', 'users', 'seats', 'bookings', 'tickets']} />
              <Field label="Record ID" name="lookupId" type="number" value={apiTools.lookupId} onChange={setField(setApiTools)} />
              <button className="primary-btn" type="submit">Load by ID</button>
            </form>
            <form onSubmit={runFlightServiceSearch}>
              <Field label="From" name="flightSearchSource" value={apiTools.flightSearchSource} onChange={setField(setApiTools)} />
              <Field label="To" name="flightSearchDestination" value={apiTools.flightSearchDestination} onChange={setField(setApiTools)} />
              <Field label="Date" name="flightSearchDate" type="date" value={apiTools.flightSearchDate} onChange={setField(setApiTools)} />
              <Field label="Passengers" name="flightSearchPassengers" type="number" min="1" value={apiTools.flightSearchPassengers} onChange={setField(setApiTools)} />
              <button className="primary-btn" type="submit">Search flight-service</button>
            </form>
            <form onSubmit={lookupTicketByBooking}>
              <Field label="Booking ID" name="ticketBookingId" type="number" value={apiTools.ticketBookingId} onChange={setField(setApiTools)} />
              <button className="primary-btn" type="submit">Find ticket by booking</button>
            </form>
            <form onSubmit={createTicketDirect}>
              <Field label="Booking ID" name="directTicketBookingId" type="number" value={apiTools.directTicketBookingId} onChange={setField(setApiTools)} />
              <button className="primary-btn" type="submit">POST /tickets</button>
            </form>
            <form onSubmit={lookupBookingsByUser}>
              <Field label="User ID" name="bookingsUserId" type="number" value={apiTools.bookingsUserId} onChange={setField(setApiTools)} />
              <button className="primary-btn" type="submit">Bookings by user</button>
            </form>
            <form onSubmit={(event) => event.preventDefault()}>
              <Field label="Flight ID" name="syncFlightId" type="number" value={apiTools.syncFlightId} onChange={setField(setApiTools)} />
              <div className="row-actions"><button type="button" onClick={() => syncFlightSeats('decrease')}>Decrease seats</button><button type="button" onClick={() => syncFlightSeats('increase')}>Increase seats</button></div>
            </form>
            <form onSubmit={cancelTicketByBooking}>
              <Field label="Booking ID" name="ticketBookingId" type="number" value={apiTools.ticketBookingId} onChange={setField(setApiTools)} />
              <button className="primary-btn" type="submit">Cancel ticket by booking</button>
            </form>
            <ApiToolResults apiTools={apiTools} />
          </Panel>
        )}

        {activeTab === 'Flights' && (
          <Panel title="Flights">
            <div className="management-toolbar">
              <button type="button" className="primary-btn" onClick={() => { setShowFlightForm(true); setFlightForm(emptyFlight) }}>
                Add flight
              </button>
            </div>
            {showFlightForm && (
              <form onSubmit={saveFlight} className="entity-form">
                {['flightNumber', 'airline', 'source', 'destination', 'departureDate', 'departureTime', 'arrivalDate', 'arrivalTime', 'duration', 'price', 'availableSeats', 'totalSeats', 'aircraftType', 'terminal', 'gate'].map((field) => (
                  <Field key={field} label={labelize(field)} name={field} type={field.includes('Date') ? 'date' : field.includes('Time') ? 'time' : ['price', 'availableSeats', 'totalSeats'].includes(field) ? 'number' : 'text'} step="1" value={flightForm[field]} onChange={setField(setFlightForm)} />
                ))}
                <Select label="Status" name="flightStatus" value={flightForm.flightStatus} onChange={setField(setFlightForm)} options={['SCHEDULED', 'DELAYED', 'CANCELLED']} />
                <div className="row-actions">
                  <button className="primary-btn" type="submit">Save flight</button>
                  <button className="ghost-btn" type="button" onClick={() => setShowFlightForm(false)}>Cancel</button>
                </div>
              </form>
            )}
            <MiniList items={data.flights} maxItems={data.flights.length} title={(item) => `${item.flightNumber} ${item.source}-${item.destination}`} detail={(item) => `${item.airline} - ${formatMoney(item.price)}`} onEdit={editFlight} onDelete={(item) => remove('flights', item.id)} />
          </Panel>
        )}

        {activeTab === 'Users' && (
          <Panel title="Users">
            {showUserForm && (
              <form onSubmit={saveUser} className="entity-form">
                {['firstName', 'lastName', 'email', 'phoneNumber', 'password', 'dateOfBirth', 'gender', 'nationality', 'passportNumber', 'address'].map((field) => (
                  <Field key={field} label={labelize(field)} name={field} type={field === 'dateOfBirth' ? 'date' : field === 'password' ? 'password' : 'text'} value={userForm[field] || ''} onChange={setField(setUserForm)} />
                ))}
                <div className="row-actions">
                  <button className="primary-btn" type="submit">Save user</button>
                  <button className="ghost-btn" type="button" onClick={() => setShowUserForm(false)}>Cancel</button>
                </div>
              </form>
            )}
            <MiniList items={data.users} maxItems={data.users.length} title={(item) => `${item.firstName} ${item.lastName}`} detail={(item) => item.email} onEdit={editUser} onDelete={(item) => remove('users', item.id)} />
          </Panel>
        )}

        {activeTab === 'Seats' && (
          <Panel title="Seats">
            {showSeatForm && (
              <form onSubmit={saveSeat} className="entity-form">
                {flightOptions.length ? (
                  <Select
                    label="Flight number"
                    name="flightNumber"
                    value={seatForm.flightNumber}
                    onChange={setField(setSeatForm)}
                    options={flightOptions}
                  />
                ) : (
                  <Field
                    label="Flight ID"
                    name="flightId"
                    type="number"
                    value={seatForm.flightId}
                    onChange={setField(setSeatForm)}
                  />
                )}
                <Field label="Seat number" name="seatNumber" value={seatForm.seatNumber} onChange={setField(setSeatForm)} />
                <Select label="Type" name="seatType" value={seatForm.seatType} onChange={setField(setSeatForm)} options={['Window', 'Aisle', 'Middle']} />
                <Select label="Class" name="seatClass" value={seatForm.seatClass} onChange={setField(setSeatForm)} options={['Economy', 'Business', 'First']} />
                <Field label="Price" name="price" type="number" value={seatForm.price} onChange={setField(setSeatForm)} />
                <Select label="Status" name="status" value={seatForm.status} onChange={setField(setSeatForm)} options={['AVAILABLE', 'RESERVED']} />
                <div className="row-actions">
                  <button className="primary-btn" type="submit">Save seat</button>
                  <button className="ghost-btn" type="button" onClick={() => setShowSeatForm(false)}>Cancel</button>
                </div>
              </form>
            )}
            <MiniList items={data.seats.filter((s) => s.status !== 'AVAILABLE')} maxItems={data.seats.length} title={(item) => `${item.seatNumber} - Flight ${getFlightNumberForId(item.flightId) || item.flightId}`} detail={(item) => `${item.seatClass} - ${item.status}`} onEdit={editSeat} onToggle={reserveOrRelease} toggleLabel={(item) => (item.status === 'AVAILABLE' ? 'Reserve' : 'Release')} onDelete={(item) => remove('seats', item.id)} />
          </Panel>
        )}

        {activeTab === 'Bookings' && (
          <Panel title="Bookings">
            {showBookingForm && (
              <form onSubmit={updateBooking} className="entity-form">
                {['id', 'userId', 'flightId', 'seatId', 'totalFare'].map((field) => (
                  <Field key={field} label={labelize(field)} name={field} type="number" value={bookingEdit[field]} onChange={setField(setBookingEdit)} />
                ))}
                <Select label="Booking status" name="bookingStatus" value={bookingEdit.bookingStatus} onChange={setField(setBookingEdit)} options={['CONFIRMED', 'PENDING', 'CANCELLED']} />
                <Select label="Payment status" name="paymentStatus" value={bookingEdit.paymentStatus} onChange={setField(setBookingEdit)} options={['PAID', 'PENDING', 'FAILED']} />
                <div className="row-actions">
                  <button className="primary-btn" type="submit">Update booking</button>
                  <button className="ghost-btn" type="button" onClick={() => setShowBookingForm(false)}>Cancel</button>
                </div>
              </form>
            )}
            <MiniList items={data.bookings} maxItems={data.bookings.length} title={(item) => item.bookingReference} detail={(item) => `Seat ${item.seatNumber} - ${item.bookingStatus}`} onEdit={editBooking} onDelete={(item) => remove('bookings', item.id)} />
          </Panel>
        )}

        {activeTab === 'Tickets' && (
          <Panel title="Tickets">
            {showTicketForm && (
              <form onSubmit={updateTicket} className="entity-form">
                <Field label="Ticket ID" name="id" type="number" value={ticketEdit.id} onChange={setField(setTicketEdit)} />
                <Field label="Booking ID" name="bookingId" type="number" value={ticketEdit.bookingId} onChange={setField(setTicketEdit)} />
                <Select label="Status" name="ticketStatus" value={ticketEdit.ticketStatus} onChange={setField(setTicketEdit)} options={['ISSUED', 'CANCELLED']} />
                <div className="row-actions">
                  <button className="primary-btn" type="submit">Update ticket</button>
                  <button className="ghost-btn" type="button" onClick={() => setShowTicketForm(false)}>Cancel</button>
                </div>
              </form>
            )}
            <MiniList items={data.tickets} maxItems={data.tickets.length} title={(item) => item.ticketNumber} detail={(item) => `Booking ${item.bookingId} - ${item.ticketStatus}`} onEdit={editTicket} onToggle={(item) => cancelTicket(item.id)} toggleLabel={() => 'Cancel'} onDelete={(item) => remove('tickets', item.id)} />
          </Panel>
        )}
      </div>
    </div>
  )
}

function ApiToolResults({ apiTools }) {
  const hasResults =
    apiTools.lookupResult ||
    apiTools.flightSearchResult ||
    apiTools.ticketLookupResult ||
    apiTools.directTicketResult

  if (!hasResults) {
    return <p className="compact">Run an API tool to see formatted results here.</p>
  }

  return (
    <div className="api-results">
      {apiTools.lookupResult && (
        <ResultSection title="Lookup result">
          <KeyValueCard data={apiTools.lookupResult} />
        </ResultSection>
      )}

      {apiTools.flightSearchResult && (
        <ResultSection title="Flight-service search results">
          <div className="api-flight-list">
            {apiTools.flightSearchResult.length ? (
              apiTools.flightSearchResult.map((flight) => (
                <article className="api-flight-card" key={flight.id}>
                  <div>
                    <strong>{flight.airline}</strong>
                    <span>{flight.flightNumber}</span>
                  </div>
                  <div>
                    <b>{flight.source}</b>
                    <span>{flight.departureTime?.slice(0, 5)} to {flight.arrivalTime?.slice(0, 5)}</span>
                    <b>{flight.destination}</b>
                  </div>
                  <div>
                    <span>{flight.departureDate}</span>
                    <span>{flight.duration}</span>
                    <strong>{formatMoney(flight.price)}</strong>
                  </div>
                </article>
              ))
            ) : (
              <p className="compact">No flights matched this route.</p>
            )}
          </div>
        </ResultSection>
      )}

      {apiTools.ticketLookupResult && (
        <ResultSection title="Ticket by booking">
          <TicketSummary ticket={apiTools.ticketLookupResult} />
        </ResultSection>
      )}

      {apiTools.directTicketResult && (
        <ResultSection title="Generated ticket">
          <TicketSummary ticket={apiTools.directTicketResult} />
        </ResultSection>
      )}
      {apiTools.bookingsByUserResult && (
        <ResultSection title="Bookings by user"><div className="api-flight-list">{apiTools.bookingsByUserResult.map((booking) => <KeyValueCard key={booking.id} data={booking} />)}</div></ResultSection>
      )}
    </div>
  )
}

function ResultSection({ title, children }) {
  return (
    <section className="result-section">
      <h3>{title}</h3>
      {children}
    </section>
  )
}

function KeyValueCard({ data }) {
  return (
    <dl className="key-value-card">
      {Object.entries(data).map(([key, value]) => (
        <div key={key}>
          <dt>{labelize(key)}</dt>
          <dd>{String(value ?? '-')}</dd>
        </div>
      ))}
    </dl>
  )
}

function TicketSummary({ ticket }) {
  return (
    <article className="ticket-summary">
      <strong>{ticket.ticketNumber || `Ticket ${ticket.id}`}</strong>
      <span>Booking {ticket.bookingId}</span>
      <span>Flight {ticket.flightId}</span>
      <span>User {ticket.userId}</span>
      <span>Seat {ticket.seatNumber}</span>
      <b>{ticket.ticketStatus}</b>
    </article>
  )
}
