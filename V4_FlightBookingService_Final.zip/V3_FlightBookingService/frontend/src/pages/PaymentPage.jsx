import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { bookingApi, ticketApi } from '../api'
import { formatMoney } from '../utils/format'

export function PaymentPage({ refreshData, setLoading, setNotice, showToast }) {
  const location = useLocation()
  const navigate = useNavigate()
  const [booking, setBooking] = useState(location.state?.booking || null)
  const [paymentMethod, setPaymentMethod] = useState('UPI')
  const [ticket, setTicket] = useState(null)

  useEffect(() => {
    if (!booking) {
      navigate('/booking', { replace: true })
    }
  }, [booking, navigate])

  const amount = Number(booking?.totalFare || 0)
  const gstAmount = Number((amount * 0.18).toFixed(2))
  const grandTotal = Number((amount + gstAmount).toFixed(2))

  const fail = (error) => {
    setNotice(error.message)
    showToast(error.message, 'error')
  }

  const success = (message) => {
    setNotice(message)
    showToast(message, 'success')
  }

  const cancelBooking = async () => {
    if (!booking || booking.bookingStatus === 'CANCELLED') return

    setLoading(true)
    try {
      const cancelled = await bookingApi.cancel(booking.id)
      setBooking(cancelled)
      success('Booking cancelled successfully.')
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const downloadTicket = async (ticketId) => {
    try {
      const blob = await ticketApi.download(ticketId)
      const url = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = url
      anchor.download = `${ticket?.ticketNumber || `ticket-${ticketId}`}.pdf`
      anchor.click()
      URL.revokeObjectURL(url)
    } catch (error) {
      fail(error)
    }
  }

  const payNow = async () => {
    if (!booking || booking.bookingStatus === 'CANCELLED' || booking.paymentStatus === 'PAID') return

    setLoading(true)
    try {
      const updated = await bookingApi.update(booking.id, {
        userId: booking.userId,
        flightId: booking.flightId,
        seatId: booking.seatId,
        bookingStatus: 'CONFIRMED',
        paymentStatus: 'PAID',
        totalFare: booking.totalFare,
      })
      setBooking(updated)
      success(`Payment completed via ${paymentMethod}.`)
      const generated = await ticketApi.generate({
        bookingId: updated.id,
        ticketStatus: 'ISSUED',
      })
      setTicket(generated)
      success(`Ticket generated: ${generated.ticketNumber}`)
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  if (!booking) {
    return null
  }

  return (
    <section className="payment-page">
      <div className="payment-card">
        <h2>Payment</h2>
        <p>Please confirm your booking payment or cancel the booking. Cancellations are processed on the backend.</p>

        <div className="payment-summary">
          <div>
            <strong>Booking reference</strong>
            <span>{booking.bookingReference}</span>
          </div>
          <div>
            <strong>Flight</strong>
            <span>{booking.flightNumber || `#${booking.flightId}`}</span>
          </div>
          <div>
            <strong>Route</strong>
            <span>{booking.source || '—'} → {booking.destination || '—'}</span>
          </div>
          <div>
            <strong>Seat</strong>
            <span>{booking.seatNumber || '—'}</span>
          </div>
          <div>
            <strong>Status</strong>
            <span>{booking.bookingStatus}</span>
          </div>
          <div>
            <strong>Payment</strong>
            <span>{booking.paymentStatus}</span>
          </div>
        </div>

        <div className="payment-details">
          <div className="payment-row">
            <span>Fare</span>
            <strong>{formatMoney(amount)}</strong>
          </div>
          <div className="payment-row">
            <span>GST (18%)</span>
            <strong>{formatMoney(gstAmount)}</strong>
          </div>
          <div className="payment-row total">
            <span>Amount payable</span>
            <strong>{formatMoney(grandTotal)}</strong>
          </div>
        </div>

        <label className="payment-method">
          <span>Payment method</span>
          <select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)}>
            <option value="UPI">UPI</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Debit Card">Debit Card</option>
            <option value="NetBanking">NetBanking</option>
          </select>
        </label>

        <div className="payment-actions">
          <button
            className="ghost-btn"
            type="button"
            disabled={booking.bookingStatus === 'CANCELLED' || booking.paymentStatus === 'PAID'}
            onClick={cancelBooking}
          >
            Cancel booking
          </button>
          <button
            className="primary-btn"
            type="button"
            disabled={booking.bookingStatus === 'CANCELLED' || booking.paymentStatus === 'PAID'}
            onClick={payNow}
          >
            {booking.paymentStatus === 'PAID' ? 'Payment completed' : 'Pay now'}
          </button>
        </div>

        {ticket && (
          <div className="ticket-box issued" style={{ marginTop: '16px', padding: '18px' }}>
            <strong>{ticket.ticketNumber}</strong>
            <span>{ticket.ticketStatus}</span>
            <button className="primary-btn" type="button" onClick={() => downloadTicket(ticket.id)}>
              Download PDF ticket
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
