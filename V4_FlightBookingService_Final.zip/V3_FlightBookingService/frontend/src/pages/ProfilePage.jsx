import { useEffect, useState } from 'react'
import { userApi } from '../api'
import { Field } from '../components/FormControls'
import { Panel } from '../components/Panel'

const profileFields = ['firstName', 'lastName', 'email', 'phoneNumber', 'dateOfBirth', 'gender', 'nationality', 'passportNumber', 'address']
export function ProfilePage() {
  const [profile, setProfile] = useState({})
  const [form, setForm] = useState({})
  const [editing, setEditing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    userApi
      .me()
      .then((result) => {
        setProfile(result)
        setForm(result)
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  const submit = async (event) => {
    event.preventDefault()
    setLoading(true)
    setMessage('')
    setError('')

    try {
      const updated = await userApi.updateMe({
        ...form,
        password: form.password || undefined,
      })
      setProfile(updated)
      setForm(updated)
      setEditing(false)
      setMessage('Profile updated.')
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const startEdit = () => {
    setForm(profile)
    setEditing(true)
    setMessage('')
    setError('')
  }

  const cancelEdit = () => {
    setForm(profile)
    setEditing(false)
    setMessage('')
    setError('')
  }

  const fieldLabel = (field) => field.replace(/([A-Z])/g, ' $1')

  return (
    <div className="account-page">
      <Panel title="My profile">
        <div className="profile-head">
          <p className="compact">View and update the profile used for your bookings.</p>
         
        </div>

        {!editing ? (
          <div className="profile-summary">
            {profileFields.map((field) => (
              <div className="profile-row" key={field}>
                <span className="profile-label">{fieldLabel(field)}</span>
                <span className="profile-value">
                  {field === 'dateOfBirth' ? profile[field]?.slice(0, 10) : profile[field] || '—'}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <form className="profile-form" onSubmit={submit}>
            {profileFields.map((field) => (
              <Field
                key={field}
                label={fieldLabel(field)}
                name={field}
                type={field === 'dateOfBirth' ? 'date' : field === 'email' ? 'email' : 'text'}
                value={form[field] || ''}
                onChange={(e) => setForm({ ...form, [field]: e.target.value })}
              />
            ))}
            <Field
              label="New password (optional)"
              name="password"
              type="password"
              required={false}
              value={form.password || ''}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
            <div className="profile-actions">
              <button className="primary-btn" disabled={loading} type="submit">
                {loading ? 'Saving…' : 'Save profile'}
              </button>
              <button className="ghost-btn" type="button" onClick={cancelEdit}>
                Cancel
              </button>
            </div>
          </form>
        )}
         {!editing && (
            <button type="button" className="primary-btn" onClick={startEdit}>
              Edit profile
            </button>
          )}
        {message && <p className="success-message">{message}</p>}
        {error && <p className="notice error">{error}</p>}
      </Panel>
    </div>
  )
}
